# Course Manager Details

Link to Deployed Web-App: https://course-manager-8dky6eqp0-sandras-projects-c89bb756.vercel.app/

## How to Run

In the project directory, you first run:

### `npm install`

Installs the node modules needed to run the program.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

## Bugs

There are no known bugs.
